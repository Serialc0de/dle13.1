Dear friends,

Before you start working with the script we recommend you read yourself 
the documentation in the file Documentation/readme.chm

Instructions for a new installation script is in the file Documentation/install.html

How to update the script from older versions is in the file Documentation/upgrade.html
 