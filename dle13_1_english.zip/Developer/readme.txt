In order to increase the speed of loading pages 
we use in the engine, encrypted and compressed Javascript files 
if you want to modify, then use uncompressed files.